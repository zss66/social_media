/*
 * @Author: zss66 zjb520zll@gmail.com
 * @Date: 2025-07-22 10:57:07
 * @LastEditors: zss66 zjb520zll@gmail.com
 * @LastEditTime: 2025-07-22 11:02:52
 * @FilePath: \social_media\public\preload.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
const { contextBridge, ipcRenderer } = require('electron')

// 向渲染进程暴露安全的API
contextBridge.exposeInMainWorld('electronAPI', {
  // 窗口控制
  minimize: () => ipcRenderer.invoke('minimize-window'),
  close: () => ipcRenderer.invoke('close-window'),
  toggleDevTools: () => ipcRenderer.invoke('toggle-devtools'),
  
  // 容器管理
  createContainerSession: (containerId, config) => 
    ipcRenderer.invoke('create-container-session', containerId, config),
  
  testProxy: (proxyConfig) => 
    ipcRenderer.invoke('test-proxy', proxyConfig),
  
  // 翻译服务
  translateText: (text, targetLang) => 
    ipcRenderer.invoke('translate-text', text, targetLang),
  
  // 截图功能
  takeScreenshot: (containerId) => 
    ipcRenderer.invoke('take-screenshot', containerId),
  
  // 文件操作
  saveFile: (data, filename) => 
    ipcRenderer.invoke('save-file', data, filename),
  
  loadFile: () => 
    ipcRenderer.invoke('load-file'),
  
  // 系统通知
  showNotification: (options) => 
    ipcRenderer.invoke('show-notification', options),
  
  // 事件监听
  onContainerMessage: (callback) => {
    ipcRenderer.on('container-message', callback)
  },
  
  removeContainerMessageListener: (callback) => {
    ipcRenderer.removeListener('container-message', callback)
  }
})

// 暴露Node.js版本信息（可选）
contextBridge.exposeInMainWorld('nodeAPI', {
  versions: process.versions
})

// 暴露平台信息
contextBridge.exposeInMainWorld('platformAPI', {
  platform: process.platform,
  arch: process.arch,
  isWindows: process.platform === 'win32',
  isMac: process.platform === 'darwin',
  isLinux: process.platform === 'linux'
})