const { app, BrowserWindow, ipcMain, session, protocol } = require('electron')
const path = require('path')
const isDev = process.env.NODE_ENV === 'development'

// 保持对窗口对象的全局引用
let mainWindow

// 创建主窗口
function createWindow() {
  // 创建浏览器窗口
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    show: false,
    frame: false,
    titleBarStyle: 'hidden',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      webSecurity: false,
      allowRunningInsecureContent: true,
      experimentalFeatures: true,
      webviewTag: true,
      preload: path.join(__dirname, 'preload.js')
    }
  })

  // 加载应用
  const startUrl = isDev 
    ? 'http://localhost:8080' 
    : `file://${path.join(__dirname, '../dist/index.html')}`
  
  mainWindow.loadURL(startUrl)

  // 当窗口准备好时显示
  mainWindow.once('ready-to-show', () => {
    mainWindow.show()
    
    if (isDev) {
      mainWindow.webContents.openDevTools()
    }
  })

  // 当窗口关闭时
  mainWindow.on('closed', () => {
    mainWindow = null
  })

  // 处理外部链接
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    require('electron').shell.openExternal(url)
    return { action: 'deny' }
  })
}

// 设置会话分区和代理
function setupSessions() {
  // 为每个容器创建独立的会话分区
  const createContainerSession = (containerId, config = {}) => {
    const partition = `persist:container_${containerId}`
    const ses = session.fromPartition(partition)
    
    // 设置用户代理
    if (config.fingerprint && config.fingerprint.userAgent) {
      ses.setUserAgent(config.fingerprint.userAgent)
    }
    
    // 设置代理
    if (config.proxy && config.proxy.enabled) {
      const proxyConfig = {
        proxyRules: `${config.proxy.type}://${config.proxy.host}:${config.proxy.port}`
      }
      
      if (config.proxy.username && config.proxy.password) {
        // 处理代理认证
        ses.setProxy(proxyConfig).then(() => {
          ses.on('login', (event, request, authInfo, callback) => {
            event.preventDefault()
            callback(config.proxy.username, config.proxy.password)
          })
        })
      } else {
        ses.setProxy(proxyConfig)
      }
    }
    
    // 设置请求头
    ses.webRequest.onBeforeSendHeaders((details, callback) => {
      const headers = { ...details.requestHeaders }
      
      // 添加自定义请求头
      if (config.fingerprint) {
        if (config.fingerprint.language) {
          headers['Accept-Language'] = config.fingerprint.language.join(',')
        }
      }
      
      callback({ requestHeaders: headers })
    })
    
    return ses
  }
  
  // 暴露创建会话的方法
  global.createContainerSession = createContainerSession
}

// 应用事件处理
app.whenReady().then(() => {
  // 设置协议处理
  protocol.registerFileProtocol('file', (request, callback) => {
    const pathname = decodeURI(request.url.replace('file:///', ''))
    callback(pathname)
  })
  
  // 设置会话
  setupSessions()
  
  // 创建窗口
  createWindow()
  
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

// IPC 事件处理
ipcMain.handle('minimize-window', () => {
  if (mainWindow) {
    mainWindow.minimize()
  }
})

ipcMain.handle('close-window', () => {
  if (mainWindow) {
    mainWindow.close()
  }
})

ipcMain.handle('toggle-devtools', () => {
  if (mainWindow) {
    if (mainWindow.webContents.isDevToolsOpened()) {
      mainWindow.webContents.closeDevTools()
    } else {
      mainWindow.webContents.openDevTools()
    }
  }
})

// 容器管理相关IPC
ipcMain.handle('create-container-session', (event, containerId, config) => {
  try {
    const session = global.createContainerSession(containerId, config)
    return { success: true, partition: `persist:container_${containerId}` }
  } catch (error) {
    return { success: false, error: error.message }
  }
})

ipcMain.handle('test-proxy', async (event, proxyConfig) => {
  try {
    const testSession = session.fromPartition('test')
    
    await testSession.setProxy({
      proxyRules: `${proxyConfig.type}://${proxyConfig.host}:${proxyConfig.port}`
    })
    
    // 测试连接（这里可以发送一个测试请求）
    return { success: true }
  } catch (error) {
    return { success: false, error: error.message }
  }
})

// 翻译服务相关IPC
ipcMain.handle('translate-text', async (event, text, targetLang) => {
  try {
    // 这里可以集成真实的翻译API，比如Google Translate, Baidu Translate等
    // 示例使用模拟翻译
    const translatedText = await simulateTranslation(text, targetLang)
    return { success: true, translatedText }
  } catch (error) {
    return { success: false, error: error.message }
  }
})

// 模拟翻译函数
async function simulateTranslation(text, targetLang) {
  // 模拟API延迟
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  // 返回模拟翻译结果
  const langMap = {
    'en': 'English',
    'zh': '中文',
    'ja': '日本語',
    'ko': '한국어'
  }
  
  return `[${langMap[targetLang] || 'Unknown'}] ${text}`
}

// 截图相关IPC
ipcMain.handle('take-screenshot', async (event, containerId) => {
  try {
    // 这里需要获取对应容器的webview并截图
    // 实际实现需要与webview进行通信
    return { success: true, imagePath: '/path/to/screenshot.png' }
  } catch (error) {
    return { success: false, error: error.message }
  }
})

// 文件操作相关IPC
ipcMain.handle('save-file', async (event, data, filename) => {
  try {
    const { dialog } = require('electron')
    const fs = require('fs')
    
    const result = await dialog.showSaveDialog(mainWindow, {
      defaultPath: filename,
      filters: [
        { name: 'JSON Files', extensions: ['json'] },
        { name: 'All Files', extensions: ['*'] }
      ]
    })
    
    if (!result.canceled) {
      fs.writeFileSync(result.filePath, data)
      return { success: true, filePath: result.filePath }
    }
    
    return { success: false, error: 'User cancelled' }
  } catch (error) {
    return { success: false, error: error.message }
  }
})

ipcMain.handle('load-file', async (event) => {
  try {
    const { dialog } = require('electron')
    const fs = require('fs')
    
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      filters: [
        { name: 'JSON Files', extensions: ['json'] },
        { name: 'All Files', extensions: ['*'] }
      ]
    })
    
    if (!result.canceled && result.filePaths.length > 0) {
      const data = fs.readFileSync(result.filePaths[0], 'utf8')
      return { success: true, data }
    }
    
    return { success: false, error: 'User cancelled' }
  } catch (error) {
    return { success: false, error: error.message }
  }
})

// 系统通知相关IPC
ipcMain.handle('show-notification', (event, options) => {
  const { Notification } = require('electron')
  
  if (Notification.isSupported()) {
    const notification = new Notification({
      title: options.title || 'Multi Social Platform',
      body: options.body || '',
      icon: options.icon || path.join(__dirname, 'assets/icon.png')
    })
    
    notification.show()
    
    if (options.onclick) {
      notification.on('click', () => {
        mainWindow.focus()
      })
    }
    
    return { success: true }
  }
  
  return { success: false, error: 'Notifications not supported' }
})

// 应用更新相关（可选）
if (!isDev) {
  const { autoUpdater } = require('electron-updater')
  
  autoUpdater.checkForUpdatesAndNotify()
  
  autoUpdater.on('update-available', () => {
    const { dialog } = require('electron')
    dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: '应用更新',
      message: '发现新版本，正在下载更新...',
      buttons: ['确定']
    })
  })
  
  autoUpdater.on('update-downloaded', () => {
    const { dialog } = require('electron')
    dialog.showMessageBox(mainWindow, {
      type: 'info',
      title: '应用更新',
      message: '更新下载完成，应用将重启以完成更新。',
      buttons: ['立即重启', '稍后重启']
    }).then((result) => {
      if (result.response === 0) {
        autoUpdater.quitAndInstall()
      }
    })
  })
}

// 全局异常处理
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error)
})

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason)
})