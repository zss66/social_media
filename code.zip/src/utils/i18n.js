import { createI18n } from 'vue-i18n'

/**
 * 中文语言包
 */
const zhCN = {
  common: {
    confirm: '确认',
    cancel: '取消',
    save: '保存',
    delete: '删除',
    edit: '编辑',
    add: '添加',
    remove: '移除',
    close: '关闭',
    back: '返回',
    next: '下一步',
    previous: '上一步',
    submit: '提交',
    reset: '重置',
    clear: '清空',
    refresh: '刷新',
    loading: '加载中...',
    success: '操作成功',
    error: '操作失败',
    warning: '警告',
    info: '提示',
    yes: '是',
    no: '否',
    enable: '启用',
    disable: '禁用',
    online: '在线',
    offline: '离线',
    connected: '已连接',
    disconnected: '已断开',
    unknown: '未知'
  },
  
  app: {
    title: '多平台社交管理器',
    subtitle: '统一管理多个社交平台账号',
    version: '版本',
    description: '一个基于 Electron 的多平台社交软件管理器'
  },
  
  sidebar: {
    platformList: '平台列表',
    quickActions: '快捷操作',
    importConfig: '导入配置',
    exportConfig: '导出配置',
    clearAll: '清空所有'
  },
  
  container: {
    create: '创建容器',
    name: '容器名称',
    status: '状态',
    actions: '操作',
    settings: '设置',
    reload: '重新加载',
    remove: '移除',
    created: '已创建',
    loading: '加载中',
    ready: '就绪',
    error: '错误',
    createdAt: '创建时间',
    updatedAt: '更新时间'
  },
  
  platform: {
    whatsapp: 'WhatsApp',
    telegram: 'Telegram',
    wechat: '微信',
    line: 'LINE',
    discord: 'Discord',
    slack: 'Slack',
    teams: 'Microsoft Teams',
    skype: 'Skype',
    messenger: 'Facebook Messenger',
    instagram: 'Instagram'
  },
  
  config: {
    basicInfo: '基本信息',
    proxySettings: '代理设置',
    browserFingerprint: '浏览器指纹',
    featureSettings: '功能设置',
    advancedSettings: '高级设置',
    dataManagement: '数据管理',
    
    containerName: '容器名称',
    platformInfo: '平台信息',
    enableProxy: '启用代理',
    proxyType: '代理类型',
    proxyAddress: '代理地址',
    proxyPort: '代理端口',
    username: '用户名',
    password: '密码',
    testConnection: '测试连接',
    
    enableFingerprint: '启用指纹伪装',
    presetTemplate: '预设模板',
    userAgent: 'User Agent',
    screenResolution: '屏幕分辨率',
    timezone: '时区',
    language: '语言设置',
    
    enableTranslation: '启用翻译功能',
    enableAutoReply: '启用自动回复',
    autoReplyMessage: '自动回复内容',
    replyDelay: '回复延迟',
    enableNotification: '启用消息通知',
    enableLogging: '启用消息记录',
    
    enableDevTools: '启用开发者工具',
    disableImages: '禁用图片加载',
    disableJavaScript: '禁用JavaScript',
    customCSS: '自定义CSS',
    customJS: '自定义JavaScript',
    
    clearCookies: '清理Cookie',
    clearCache: '清理缓存',
    exportData: '导出数据',
    resetContainer: '重置容器'
  },
  
  settings: {
    globalSettings: '全局设置',
    basicSettings: '基本设置',
    defaultProxy: '默认代理设置',
    translationSettings: '翻译设置',
    notificationSettings: '通知设置',
    securitySettings: '安全设置',
    advancedSettings: '高级设置',
    
    theme: '应用主题',
    lightTheme: '浅色主题',
    darkTheme: '深色主题',
    autoTheme: '跟随系统',
    language: '语言设置',
    autoStart: '开机自启动',
    minimizeToTray: '最小化到托盘',
    
    translationService: '翻译服务',
    defaultTargetLang: '默认目标语言',
    apiKey: 'API 密钥',
    autoDetectLanguage: '自动检测语言',
    
    enableDesktopNotification: '启用桌面通知',
    notificationSound: '通知声音',
    showMessagePreview: '显示消息预览',
    quietHours: '免打扰时间',
    
    appLock: '启用应用锁',
    appPassword: '应用密码',
    autoLockTime: '自动锁定时间',
    dataEncryption: '数据加密',
    clearBrowserData: '清理浏览数据',
    
    developerMode: '开发者模式',
    hardwareAcceleration: '硬件加速',
    maxContainers: '最大容器数量',
    logLevel: '日志级别',
    autoUpdate: '自动更新',
    
    restoreDefaults: '恢复默认设置',
    exportSettings: '导出设置',
    importSettings: '导入设置'
  },
  
  translation: {
    translate: '翻译',
    translating: '翻译中...',
    originalText: '原文',
    translatedText: '译文',
    copyTranslation: '复制译文',
    translationResult: '翻译结果',
    selectTextToTranslate: '请先选择要翻译的文本',
    translationFailed: '翻译失败',
    
    languages: {
      zh: '中文',
      en: '英语',
      ja: '日语',
      ko: '韩语',
      fr: '法语',
      de: '德语',
      es: '西班牙语',
      ru: '俄语'
    },
    
    services: {
      google: 'Google 翻译',
      baidu: '百度翻译',
      youdao: '有道翻译',
      tencent: '腾讯翻译'
    }
  },
  
  autoReply: {
    autoReply: '自动回复',
    enableAutoReply: '开启自动回复',
    disableAutoReply: '关闭自动回复',
    replyContent: '回复内容',
    replyDelay: '回复延迟',
    quickMessages: '快捷消息',
    autoReplied: '已自动回复',
    
    quickReplyOptions: {
      hello: '你好',
      thanks: '谢谢',
      ok: '好的',
      busy: '我现在有点忙，稍后联系',
      later: '稍后联系'
    }
  },
  
  notification: {
    newMessage: '新消息',
    containerCreated: '容器创建成功',
    containerRemoved: '容器已删除',
    settingsSaved: '设置已保存',
    dataExported: '数据已导出',
    dataImported: '数据已导入',
    proxyTestSuccess: '代理连接测试成功',
    proxyTestFailed: '代理连接测试失败',
    translationCopied: '译文已复制到剪贴板',
    screenshotSaved: '截图已保存'
  },
  
  error: {
    networkError: '网络连接失败，请检查网络设置',
    validationError: '输入数据有误，请检查后重试',
    permissionError: '权限不足，无法执行此操作',
    containerError: '容器操作失败，请重试',
    translationError: '翻译服务暂时不可用',
    proxyError: '代理连接失败，请检查代理设置',
    systemError: '系统内部错误，请重启应用',
    unknownError: '发生未知错误',
    
    containerNameRequired: '请输入容器名称',
    proxyAddressRequired: '请输入代理地址',
    proxyPortRequired: '请输入代理端口',
    invalidProxyPort: '代理端口必须在1-65535之间',
    invalidUrl: '请输入有效的URL地址',
    fileFormatError: '文件格式错误',
    
    confirmDeleteContainer: '确定要删除这个容器吗？',
    confirmResetContainer: '确定要重置此容器吗？所有数据、登录状态和自定义设置都将被清除，此操作不可撤销！',
    confirmClearAll: '确定要清空所有容器吗？此操作不可撤销！',
    confirmResetSettings: '确定要重置设置吗？所有自定义配置将被清除。',
    confirmClearCookies: '确定要清理此容器的所有Cookie吗？这将导致需要重新登录。',
    confirmClearCache: '确定要清理此容器的所有缓存吗？',
    confirmClearBrowserData: '确定要清理所有浏览数据吗？这将清除所有容器的登录状态、Cookie和缓存数据。'
  },
  
  time: {
    justNow: '刚刚',
    minutesAgo: '{n}分钟前',
    hoursAgo: '{n}小时前',
    daysAgo: '{n}天前',
    weeksAgo: '{n}周前',
    monthsAgo: '{n}个月前',
    yearsAgo: '{n}年前'
  }
}

/**
 * 英文语言包
 */
const enUS = {
  common: {
    confirm: 'Confirm',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    remove: 'Remove',
    close: 'Close',
    back: 'Back',
    next: 'Next',
    previous: 'Previous',
    submit: 'Submit',
    reset: 'Reset',
    clear: 'Clear',
    refresh: 'Refresh',
    loading: 'Loading...',
    success: 'Success',
    error: 'Error',
    warning: 'Warning',
    info: 'Info',
    yes: 'Yes',
    no: 'No',
    enable: 'Enable',
    disable: 'Disable',
    online: 'Online',
    offline: 'Offline',
    connected: 'Connected',
    disconnected: 'Disconnected',
    unknown: 'Unknown'
  },
  
  app: {
    title: 'Multi Social Platform',
    subtitle: 'Unified management of multiple social platform accounts',
    version: 'Version',
    description: 'An Electron-based multi-platform social software manager'
  },
  
  sidebar: {
    platformList: 'Platform List',
    quickActions: 'Quick Actions',
    importConfig: 'Import Config',
    exportConfig: 'Export Config',
    clearAll: 'Clear All'
  },
  
  container: {
    create: 'Create Container',
    name: 'Container Name',
    status: 'Status',
    actions: 'Actions',
    settings: 'Settings',
    reload: 'Reload',
    remove: 'Remove',
    created: 'Created',
    loading: 'Loading',
    ready: 'Ready',
    error: 'Error',
    createdAt: 'Created At',
    updatedAt: 'Updated At'
  },
  
  platform: {
    whatsapp: 'WhatsApp',
    telegram: 'Telegram',
    wechat: 'WeChat',
    line: 'LINE',
    discord: 'Discord',
    slack: 'Slack',
    teams: 'Microsoft Teams',
    skype: 'Skype',
    messenger: 'Facebook Messenger',
    instagram: 'Instagram'
  },
  
  // ... 其他翻译项目（为简洁起见，这里省略）
  // 实际项目中应该完整翻译所有字段
  
  error: {
    networkError: 'Network connection failed, please check network settings',
    validationError: 'Input data is incorrect, please check and retry',
    permissionError: 'Insufficient permissions to perform this operation',
    containerError: 'Container operation failed, please retry',
    translationError: 'Translation service is temporarily unavailable',
    proxyError: 'Proxy connection failed, please check proxy settings',
    systemError: 'System internal error, please restart the application',
    unknownError: 'An unknown error occurred'
  }
}

/**
 * 日文语言包（部分）
 */
const jaJP = {
  common: {
    confirm: '確認',
    cancel: 'キャンセル',
    save: '保存',
    delete: '削除',
    edit: '編集',
    add: '追加',
    remove: '削除',
    close: '閉じる',
    loading: '読み込み中...',
    success: '成功',
    error: 'エラー'
  },
  
  app: {
    title: 'マルチソーシャルプラットフォーム',
    subtitle: '複数のソーシャルプラットフォームアカウントの統合管理'
  }
}

/**
 * 韩文语言包（部分）
 */
const koKR = {
  common: {
    confirm: '확인',
    cancel: '취소',
    save: '저장',
    delete: '삭제',
    edit: '편집',
    add: '추가',
    remove: '제거',
    close: '닫기',
    loading: '로딩 중...',
    success: '성공',
    error: '오류'
  },
  
  app: {
    title: '멀티 소셜 플랫폼',
    subtitle: '여러 소셜 플랫폼 계정의 통합 관리'
  }
}

/**
 * 语言包集合
 */
const messages = {
  'zh-CN': zhCN,
  'en-US': enUS,
  'ja-JP': jaJP,
  'ko-KR': koKR
}

/**
 * 获取浏览器语言
 */
function getBrowserLanguage() {
  const language = navigator.language || navigator.userLanguage
  
  // 语言映射
  const languageMap = {
    'zh': 'zh-CN',
    'zh-CN': 'zh-CN',
    'zh-TW': 'zh-CN',
    'en': 'en-US',
    'en-US': 'en-US',
    'en-GB': 'en-US',
    'ja': 'ja-JP',
    'ja-JP': 'ja-JP',
    'ko': 'ko-KR',
    'ko-KR': 'ko-KR'
  }
  
  return languageMap[language] || languageMap[language.split('-')[0]] || 'zh-CN'
}

/**
 * 获取保存的语言设置
 */
function getSavedLanguage() {
  try {
    return localStorage.getItem('app-language') || getBrowserLanguage()
  } catch {
    return getBrowserLanguage()
  }
}

/**
 * 创建 i18n 实例
 */
export const i18n = createI18n({
  legacy: false, // 使用 Composition API
  locale: getSavedLanguage(),
  fallbackLocale: 'zh-CN',
  messages,
  globalInjection: true,
  silentTranslationWarn: true
})

/**
 * 切换语言
 * @param {string} locale - 语言代码
 */
export function setLanguage(locale) {
  if (!messages[locale]) {
    console.warn(`Language ${locale} is not supported`)
    return false
  }
  
  i18n.global.locale.value = locale
  
  // 保存到本地存储
  try {
    localStorage.setItem('app-language', locale)
  } catch (error) {
    console.warn('Failed to save language setting:', error)
  }
  
  // 更新 HTML lang 属性
  document.documentElement.setAttribute('lang', locale)
  
  return true
}

/**
 * 获取当前语言
 */
export function getCurrentLanguage() {
  return i18n.global.locale.value
}

/**
 * 获取支持的语言列表
 */
export function getSupportedLanguages() {
  return [
    { code: 'zh-CN', name: '简体中文', nativeName: '简体中文' },
    { code: 'en-US', name: '英语', nativeName: 'English' },
    { code: 'ja-JP', name: '日语', nativeName: '日本語' },
    { code: 'ko-KR', name: '韩语', nativeName: '한국어' }
  ]
}

/**
 * 获取翻译文本的辅助函数
 * @param {string} key - 翻译键
 * @param {object} params - 参数
 */
export function t(key, params = {}) {
  return i18n.global.t(key, params)
}

/**
 * 动态添加语言包
 * @param {string} locale - 语言代码
 * @param {object} messages - 语言包
 */
export function addLanguage(locale, messages) {
  i18n.global.setLocaleMessage(locale, messages)
}

/**
 * 检查是否支持某个语言
 * @param {string} locale - 语言代码
 */
export function isLanguageSupported(locale) {
  return messages.hasOwnProperty(locale)
}

/**
 * 格式化带参数的翻译文本
 * @param {string} template - 模板字符串
 * @param {object} params - 参数对象
 */
export function formatMessage(template, params = {}) {
  return template.replace(/\{(\w+)\}/g, (match, key) => {
    return params[key] !== undefined ? params[key] : match
  })
}

/**
 * 获取语言的文本方向
 * @param {string} locale - 语言代码
 */
export function getTextDirection(locale = getCurrentLanguage()) {
  const rtlLanguages = ['ar', 'he', 'fa', 'ur']
  const langCode = locale.split('-')[0]
  return rtlLanguages.includes(langCode) ? 'rtl' : 'ltr'
}

/**
 * 语言变化监听器
 */
const languageChangeListeners = new Set()

/**
 * 监听语言变化
 * @param {Function} callback - 回调函数
 */
export function onLanguageChange(callback) {
  languageChangeListeners.add(callback)
  
  // 返回取消监听的函数
  return () => {
    languageChangeListeners.delete(callback)
  }
}

/**
 * 触发语言变化事件
 * @param {string} newLocale - 新语言
 * @param {string} oldLocale - 旧语言
 */
function emitLanguageChange(newLocale, oldLocale) {
  languageChangeListeners.forEach(callback => {
    try {
      callback(newLocale, oldLocale)
    } catch (error) {
      console.error('Language change listener error:', error)
    }
  })
}

// 监听语言变化
let currentLocale = getCurrentLanguage()
setInterval(() => {
  const newLocale = getCurrentLanguage()
  if (newLocale !== currentLocale) {
    emitLanguageChange(newLocale, currentLocale)
    currentLocale = newLocale
  }
}, 1000)

export default i18n