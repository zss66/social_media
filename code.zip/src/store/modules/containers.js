import { ElMessage } from 'element-plus'

const state = {
  containers: [],
  activeContainer: null,
  containerSessions: new Map()
}

const getters = {
  allContainers: state => state.containers,
  activeContainer: state => state.activeContainer,
  containerById: state => id => state.containers.find(c => c.id === id),
  containersByPlatform: state => platformId => 
    state.containers.filter(c => c.platformId === platformId),
  containerCount: state => state.containers.length,
  activeContainerCount: state => 
    state.containers.filter(c => c.status === 'ready').length
}

const mutations = {
  SET_CONTAINERS(state, containers) {
    state.containers = containers
  },
  
  ADD_CONTAINER(state, container) {
    // 添加时间戳
    container.createdAt = container.createdAt || new Date().toISOString()
    container.updatedAt = new Date().toISOString()
    state.containers.push(container)
  },
  
  UPDATE_CONTAINER(state, { id, updates }) {
    const index = state.containers.findIndex(c => c.id === id)
    if (index !== -1) {
      const container = state.containers[index]
      Object.assign(container, updates, { 
        updatedAt: new Date().toISOString() 
      })
    }
  },
  
  REMOVE_CONTAINER(state, id) {
    const index = state.containers.findIndex(c => c.id === id)
    if (index !== -1) {
      state.containers.splice(index, 1)
    }
    
    // 如果删除的是当前活跃容器，清除活跃状态
    if (state.activeContainer && state.activeContainer.id === id) {
      state.activeContainer = null
    }
  },
  
  SET_ACTIVE_CONTAINER(state, container) {
    state.activeContainer = container
  },
  
  SET_CONTAINER_STATUS(state, { id, status }) {
    const container = state.containers.find(c => c.id === id)
    if (container) {
      container.status = status
      container.updatedAt = new Date().toISOString()
    }
  },
  
  SET_CONTAINER_SESSION(state, { id, session }) {
    state.containerSessions.set(id, session)
  },
  
  REMOVE_CONTAINER_SESSION(state, id) {
    state.containerSessions.delete(id)
  }
}

const actions = {
  async loadContainers({ commit }) {
    try {
      const savedContainers = localStorage.getItem('app-containers')
      if (savedContainers) {
        const containers = JSON.parse(savedContainers)
        commit('SET_CONTAINERS', containers)
      }
    } catch (error) {
      console.error('Failed to load containers:', error)
      ElMessage.error('加载容器配置失败')
    }
  },
  
  async saveContainers({ state }) {
    try {
      localStorage.setItem('app-containers', JSON.stringify(state.containers))
    } catch (error) {
      console.error('Failed to save containers:', error)
      ElMessage.error('保存容器配置失败')
    }
  },
  
  async createContainer({ commit, dispatch }, containerConfig) {
    try {
      // 生成唯一ID
      const id = `container_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      
      const container = {
        id,
        ...containerConfig,
        status: 'created',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
      
      // 如果启用了Electron API，创建会话
      if (window.electronAPI) {
        const sessionResult = await window.electronAPI.createContainerSession(
          id, 
          container.config
        )
        
        if (!sessionResult.success) {
          throw new Error(sessionResult.error || '创建容器会话失败')
        }
      }
      
      commit('ADD_CONTAINER', container)
      await dispatch('saveContainers')
      
      ElMessage.success(`容器 "${container.name}" 创建成功`)
      return container
    } catch (error) {
      console.error('Failed to create container:', error)
      ElMessage.error(`创建容器失败: ${error.message}`)
      throw error
    }
  },
  
  async updateContainer({ commit, dispatch }, { id, updates }) {
    try {
      commit('UPDATE_CONTAINER', { id, updates })
      await dispatch('saveContainers')
      
      ElMessage.success('容器设置已更新')
    } catch (error) {
      console.error('Failed to update container:', error)
      ElMessage.error('更新容器失败')
    }
  },
  
  async removeContainer({ commit, dispatch, state }, id) {
    try {
      const container = state.containers.find(c => c.id === id)
      if (!container) {
        throw new Error('容器不存在')
      }
      
      // 清理容器会话
      commit('REMOVE_CONTAINER_SESSION', id)
      
      // 删除容器
      commit('REMOVE_CONTAINER', id)
      await dispatch('saveContainers')
      
      ElMessage.success(`容器 "${container.name}" 已删除`)
    } catch (error) {
      console.error('Failed to remove container:', error)
      ElMessage.error(`删除容器失败: ${error.message}`)
    }
  },
  
  setActiveContainer({ commit }, container) {
    commit('SET_ACTIVE_CONTAINER', container)
  },
  
  updateContainerStatus({ commit }, { id, status }) {
    commit('SET_CONTAINER_STATUS', { id, status })
  },
  
  async reloadContainer({ commit, state }, id) {
    try {
      const container = state.containers.find(c => c.id === id)
      if (!container) {
        throw new Error('容器不存在')
      }
      
      commit('SET_CONTAINER_STATUS', { id, status: 'loading' })
      
      // 模拟重新加载过程
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      commit('SET_CONTAINER_STATUS', { id, status: 'ready' })
      ElMessage.success('容器已重新加载')
    } catch (error) {
      console.error('Failed to reload container:', error)
      commit('SET_CONTAINER_STATUS', { id, status: 'error' })
      ElMessage.error('重新加载容器失败')
    }
  },
  
  async clearAllContainers({ commit, dispatch }) {
    try {
      commit('SET_CONTAINERS', [])
      commit('SET_ACTIVE_CONTAINER', null)
      await dispatch('saveContainers')
      
      ElMessage.success('所有容器已清空')
    } catch (error) {
      console.error('Failed to clear containers:', error)
      ElMessage.error('清空容器失败')
    }
  },
  
  async exportContainers({ state }) {
    try {
      const data = {
        containers: state.containers,
        exportTime: new Date().toISOString(),
        version: '1.0.0'
      }
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { 
        type: 'application/json' 
      })
      
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `containers_export_${new Date().toISOString().split('T')[0]}.json`
      a.click()
      URL.revokeObjectURL(url)
      
      ElMessage.success('容器配置已导出')
    } catch (error) {
      console.error('Failed to export containers:', error)
      ElMessage.error('导出容器配置失败')
    }
  },
  
  async importContainers({ commit, dispatch }, file) {
    try {
      const text = await file.text()
      const data = JSON.parse(text)
      
      if (!data.containers || !Array.isArray(data.containers)) {
        throw new Error('无效的容器配置文件格式')
      }
      
      // 为导入的容器生成新的ID，避免冲突
      const importedContainers = data.containers.map(container => ({
        ...container,
        id: `container_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        name: `${container.name} (导入)`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'created'
      }))
      
      for (const container of importedContainers) {
        commit('ADD_CONTAINER', container)
      }
      
      await dispatch('saveContainers')
      
      ElMessage.success(`成功导入 ${importedContainers.length} 个容器`)
    } catch (error) {
      console.error('Failed to import containers:', error)
      ElMessage.error(`导入容器配置失败: ${error.message}`)
    }
  }
}

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
}