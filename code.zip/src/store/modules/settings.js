import { ElMessage } from 'element-plus'

// 默认设置
const defaultSettings = {
  // 基本设置
  theme: 'light',
  language: 'zh-CN',
  autoStart: false,
  minimizeToTray: true,
  
  // 默认代理设置
  defaultProxy: {
    enabled: false,
    type: 'http',
    host: '',
    port: 8080,
    username: '',
    password: ''
  },
  
  // 翻译设置
  translation: {
    service: 'google',
    defaultTargetLang: 'zh',
    apiKey: '',
    autoDetect: true
  },
  
  // 通知设置
  notification: {
    enabled: true,
    sound: true,
    showPreview: true,
    quietHours: []
  },
  
  // 安全设置
  security: {
    appLock: false,
    password: '',
    autoLockTime: 30,
    dataEncryption: false
  },
  
  // 高级设置
  advanced: {
    developerMode: false,
    hardwareAcceleration: true,
    maxContainers: 20,
    logLevel: 'info',
    autoUpdate: true
  }
}

const state = {
  settings: { ...defaultSettings },
  settingsLoaded: false
}

const getters = {
  allSettings: state => state.settings,
  settingsLoaded: state => state.settingsLoaded,
  
  // 基本设置
  theme: state => state.settings.theme,
  language: state => state.settings.language,
  autoStart: state => state.settings.autoStart,
  minimizeToTray: state => state.settings.minimizeToTray,
  
  // 代理设置
  defaultProxy: state => state.settings.defaultProxy,
  
  // 翻译设置
  translationSettings: state => state.settings.translation,
  
  // 通知设置
  notificationSettings: state => state.settings.notification,
  
  // 安全设置
  securitySettings: state => state.settings.security,
  
  // 高级设置
  advancedSettings: state => state.settings.advanced,
  
  // 是否启用开发者模式
  isDeveloperMode: state => state.settings.advanced.developerMode,
  
  // 最大容器数量
  maxContainers: state => state.settings.advanced.maxContainers
}

const mutations = {
  SET_SETTINGS(state, settings) {
    state.settings = { ...defaultSettings, ...settings }
  },
  
  UPDATE_SETTING(state, { key, value }) {
    // 支持嵌套键，如 'translation.service'
    const keys = key.split('.')
    let target = state.settings
    
    for (let i = 0; i < keys.length - 1; i++) {
      if (!target[keys[i]]) {
        target[keys[i]] = {}
      }
      target = target[keys[i]]
    }
    
    target[keys[keys.length - 1]] = value
  },
  
  RESET_SETTINGS(state) {
    state.settings = { ...defaultSettings }
  },
  
  SET_SETTINGS_LOADED(state, loaded) {
    state.settingsLoaded = loaded
  }
}

const actions = {
  async loadSettings({ commit }) {
    try {
      const savedSettings = localStorage.getItem('app-settings')
      if (savedSettings) {
        const settings = JSON.parse(savedSettings)
        commit('SET_SETTINGS', settings)
      }
      commit('SET_SETTINGS_LOADED', true)
    } catch (error) {
      console.error('Failed to load settings:', error)
      commit('SET_SETTINGS', defaultSettings)
      commit('SET_SETTINGS_LOADED', true)
      ElMessage.error('加载设置失败，已恢复默认设置')
    }
  },
  
  async saveSettings({ state }) {
    try {
      localStorage.setItem('app-settings', JSON.stringify(state.settings))
    } catch (error) {
      console.error('Failed to save settings:', error)
      ElMessage.error('保存设置失败')
      throw error
    }
  },
  
  async updateSetting({ commit, dispatch }, { key, value }) {
    try {
      commit('UPDATE_SETTING', { key, value })
      await dispatch('saveSettings')
    } catch (error) {
      console.error('Failed to update setting:', error)
      ElMessage.error('更新设置失败')
    }
  },
  
  async updateSettings({ commit, dispatch }, settings) {
    try {
      commit('SET_SETTINGS', settings)
      await dispatch('saveSettings')
      ElMessage.success('设置已保存')
    } catch (error) {
      console.error('Failed to update settings:', error)
      ElMessage.error('保存设置失败')
    }
  },
  
  async resetSettings({ commit, dispatch }) {
    try {
      commit('RESET_SETTINGS')
      await dispatch('saveSettings')
      ElMessage.success('设置已重置为默认值')
    } catch (error) {
      console.error('Failed to reset settings:', error)
      ElMessage.error('重置设置失败')
    }
  },
  
  async exportSettings({ state }) {
    try {
      const data = {
        settings: state.settings,
        exportTime: new Date().toISOString(),
        version: '1.0.0'
      }
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { 
        type: 'application/json' 
      })
      
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `settings_export_${new Date().toISOString().split('T')[0]}.json`
      a.click()
      URL.revokeObjectURL(url)
      
      ElMessage.success('设置已导出')
    } catch (error) {
      console.error('Failed to export settings:', error)
      ElMessage.error('导出设置失败')
    }
  },
  
  async importSettings({ commit, dispatch }, file) {
    try {
      const text = await file.text()
      const data = JSON.parse(text)
      
      if (!data.settings) {
        throw new Error('无效的设置文件格式')
      }
      
      // 验证设置数据的完整性
      const importedSettings = { ...defaultSettings, ...data.settings }
      
      commit('SET_SETTINGS', importedSettings)
      await dispatch('saveSettings')
      
      ElMessage.success('设置已导入')
    } catch (error) {
      console.error('Failed to import settings:', error)
      ElMessage.error(`导入设置失败: ${error.message}`)
    }
  },
  
  // 应用主题设置
  async applyTheme({ commit, dispatch }, theme) {
    try {
      await dispatch('updateSetting', { key: 'theme', value: theme })
      
      // 应用主题到文档
      document.documentElement.setAttribute('data-theme', theme)
      if (theme === 'dark') {
        document.documentElement.classList.add('dark')
      } else {
        document.documentElement.classList.remove('dark')
      }
      
      // 通知主进程（如果在Electron环境中）
      if (window.electronAPI && window.electronAPI.setTheme) {
        window.electronAPI.setTheme(theme)
      }
    } catch (error) {
      console.error('Failed to apply theme:', error)
      ElMessage.error('应用主题失败')
    }
  },
  
  // 应用语言设置
  async applyLanguage({ dispatch }, language) {
    try {
      await dispatch('updateSetting', { key: 'language', value: language })
      
      // 这里可以集成i18n来切换语言
      // 暂时只是保存设置
      
      ElMessage.success('语言设置已更新')
    } catch (error) {
      console.error('Failed to apply language:', error)
      ElMessage.error('应用语言设置失败')
    }
  },
  
  // 测试代理设置
  async testProxy({ state }) {
    try {
      const proxyConfig = state.settings.defaultProxy
      
      if (!proxyConfig.enabled) {
        throw new Error('代理未启用')
      }
      
      if (window.electronAPI && window.electronAPI.testProxy) {
        const result = await window.electronAPI.testProxy(proxyConfig)
        
        if (result.success) {
          ElMessage.success('代理连接测试成功')
          return true
        } else {
          throw new Error(result.error || '代理连接测试失败')
        }
      } else {
        // 浏览器环境下的模拟测试
        await new Promise(resolve => setTimeout(resolve, 2000))
        ElMessage.success('代理连接测试成功（模拟）')
        return true
      }
    } catch (error) {
      console.error('Proxy test failed:', error)
      ElMessage.error(`代理测试失败: ${error.message}`)
      return false
    }
  },
  
  // 应用安全设置
  async applySecurity({ state, dispatch }) {
    try {
      const { appLock, dataEncryption } = state.settings.security
      
      // 这里可以实现具体的安全功能
      // 比如设置应用锁、数据加密等
      
      if (appLock) {
        // 启用应用锁逻辑
      }
      
      if (dataEncryption) {
        // 启用数据加密逻辑
      }
      
      await dispatch('saveSettings')
      ElMessage.success('安全设置已应用')
    } catch (error) {
      console.error('Failed to apply security settings:', error)
      ElMessage.error('应用安全设置失败')
    }
  }
}

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
}