<template>
  <div class="global-settings">
    <el-form ref="formRef" :model="settings" label-width="140px">
      <!-- 基本设置 -->
      <el-card class="settings-section" shadow="never">
        <template #header>
          <div class="section-header">
            <el-icon><Setting /></el-icon>
            基本设置
          </div>
        </template>
        
        <el-form-item label="应用主题">
          <el-radio-group v-model="settings.theme">
            <el-radio label="light">浅色主题</el-radio>
            <el-radio label="dark">深色主题</el-radio>
            <el-radio label="auto">跟随系统</el-radio>
          </el-radio-group>
        </el-form-item>
        
        <el-form-item label="语言设置">
          <el-select v-model="settings.language" placeholder="选择语言">
            <el-option label="简体中文" value="zh-CN" />
            <el-option label="English" value="en-US" />
            <el-option label="日本語" value="ja-JP" />
            <el-option label="한국어" value="ko-KR" />
          </el-select>
        </el-form-item>
        
        <el-form-item label="开机自启动">
          <el-switch v-model="settings.autoStart" />
          <div class="form-item-description">
            应用将在系统启动时自动运行
          </div>
        </el-form-item>
        
        <el-form-item label="最小化到托盘">
          <el-switch v-model="settings.minimizeToTray" />
          <div class="form-item-description">
            关闭窗口时最小化到系统托盘而不是退出
          </div>
        </el-form-item>
      </el-card>
      
      <!-- 默认代理设置 -->
      <el-card class="settings-section" shadow="never">
        <template #header>
          <div class="section-header">
            <el-icon><Link /></el-icon>
            默认代理设置
          </div>
        </template>
        
        <el-form-item label="启用全局代理">
          <el-switch v-model="settings.defaultProxy.enabled" />
          <div class="form-item-description">
            新创建的容器将默认使用此代理配置
          </div>
        </el-form-item>
        
        <template v-if="settings.defaultProxy.enabled">
          <el-form-item label="代理类型">
            <el-select v-model="settings.defaultProxy.type">
              <el-option label="HTTP" value="http" />
              <el-option label="HTTPS" value="https" />
              <el-option label="SOCKS4" value="socks4" />
              <el-option label="SOCKS5" value="socks5" />
            </el-select>
          </el-form-item>
          
          <el-row :gutter="20">
            <el-col :span="16">
              <el-form-item label="代理地址">
                <el-input v-model="settings.defaultProxy.host" placeholder="127.0.0.1" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="端口">
                <el-input-number 
                  v-model="settings.defaultProxy.port" 
                  :min="1" 
                  :max="65535"
                  style="width: 100%"
                />
              </el-form-item>
            </el-col>
          </el-row>
          
          <el-row :gutter="20">
            <el-col :span="12">
              <el-form-item label="用户名">
                <el-input v-model="settings.defaultProxy.username" />
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="密码">
                <el-input 
                  v-model="settings.defaultProxy.password" 
                  type="password" 
                  show-password 
                />
              </el-form-item>
            </el-col>
          </el-row>
        </template>
      </el-card>
      
      <!-- 翻译设置 -->
      <el-card class="settings-section" shadow="never">
        <template #header>
          <div class="section-header">
            <el-icon><ChatDotRound /></el-icon>
            翻译设置
          </div>
        </template>
        
        <el-form-item label="翻译服务">
          <el-select v-model="settings.translation.service">
            <el-option label="Google 翻译" value="google" />
            <el-option label="百度翻译" value="baidu" />
            <el-option label="有道翻译" value="youdao" />
            <el-option label="腾讯翻译" value="tencent" />
          </el-select>
        </el-form-item>
        
        <el-form-item label="默认目标语言">
          <el-select v-model="settings.translation.defaultTargetLang">
            <el-option label="中文" value="zh" />
            <el-option label="英语" value="en" />
            <el-option label="日语" value="ja" />
            <el-option label="韩语" value="ko" />
          </el-select>
        </el-form-item>
        
        <el-form-item label="API 密钥">
          <el-input 
            v-model="settings.translation.apiKey" 
            type="password" 
            placeholder="请输入翻译服务的API密钥"
            show-password
          />
          <div class="form-item-description">
            用于调用翻译API，请确保密钥有效
          </div>
        </el-form-item>
        
        <el-form-item label="自动检测语言">
          <el-switch v-model="settings.translation.autoDetect" />
        </el-form-item>
      </el-card>
      
      <!-- 通知设置 -->
      <el-card class="settings-section" shadow="never">
        <template #header>
          <div class="section-header">
            <el-icon><Bell /></el-icon>
            通知设置
          </div>
        </template>
        
        <el-form-item label="启用桌面通知">
          <el-switch v-model="settings.notification.enabled" />
        </el-form-item>
        
        <template v-if="settings.notification.enabled">
          <el-form-item label="通知声音">
            <el-switch v-model="settings.notification.sound" />
          </el-form-item>
          
          <el-form-item label="显示消息预览">
            <el-switch v-model="settings.notification.showPreview" />
            <div class="form-item-description">
              在通知中显示消息内容预览
            </div>
          </el-form-item>
          
          <el-form-item label="免打扰时间">
            <el-time-picker
              v-model="settings.notification.quietHours"
              is-range
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              format="HH:mm"
            />
          </el-form-item>
        </template>
      </el-card>
      
      <!-- 安全设置 -->
      <el-card class="settings-section" shadow="never">
        <template #header>
          <div class="section-header">
            <el-icon><Lock /></el-icon>
            安全设置
          </div>
        </template>
        
        <el-form-item label="启用应用锁">
          <el-switch v-model="settings.security.appLock" />
          <div class="form-item-description">
            应用启动时需要输入密码
          </div>
        </el-form-item>
        
        <template v-if="settings.security.appLock">
          <el-form-item label="应用密码">
            <el-input 
              v-model="settings.security.password" 
              type="password" 
              placeholder="设置应用锁密码"
              show-password
            />
          </el-form-item>
          
          <el-form-item label="自动锁定时间">
            <el-select v-model="settings.security.autoLockTime">
              <el-option label="5分钟" :value="5" />
              <el-option label="10分钟" :value="10" />
              <el-option label="30分钟" :value="30" />
              <el-option label="1小时" :value="60" />
              <el-option label="永不" :value="0" />
            </el-select>
          </el-form-item>
        </template>
        
        <el-form-item label="数据加密">
          <el-switch v-model="settings.security.dataEncryption" />
          <div class="form-item-description">
            加密保存的配置和数据文件
          </div>
        </el-form-item>
        
        <el-form-item label="清理浏览数据">
          <el-button @click="clearBrowserData" type="warning" plain>
            清理所有浏览数据
          </el-button>
          <div class="form-item-description">
            清理所有容器的Cookie、缓存等数据
          </div>
        </el-form-item>
      </el-card>
      
      <!-- 高级设置 -->
      <el-card class="settings-section" shadow="never">
        <template #header>
          <div class="section-header">
            <el-icon><Tools /></el-icon>
            高级设置
          </div>
        </template>
        
        <el-form-item label="开发者模式">
          <el-switch v-model="settings.advanced.developerMode" />
          <div class="form-item-description">
            启用调试功能和开发者工具
          </div>
        </el-form-item>
        
        <el-form-item label="硬件加速">
          <el-switch v-model="settings.advanced.hardwareAcceleration" />
          <div class="form-item-description">
            使用GPU加速渲染（重启后生效）
          </div>
        </el-form-item>
        
        <el-form-item label="最大容器数量">
          <el-input-number 
            v-model="settings.advanced.maxContainers" 
            :min="1" 
            :max="50"
          />
          <div class="form-item-description">
            同时运行的容器数量限制
          </div>
        </el-form-item>
        
        <el-form-item label="日志级别">
          <el-select v-model="settings.advanced.logLevel">
            <el-option label="错误" value="error" />
            <el-option label="警告" value="warn" />
            <el-option label="信息" value="info" />
            <el-option label="调试" value="debug" />
          </el-select>
        </el-form-item>
        
        <el-form-item label="自动更新">
          <el-switch v-model="settings.advanced.autoUpdate" />
          <div class="form-item-description">
            自动检查并下载应用更新
          </div>
        </el-form-item>
      </el-card>
    </el-form>
    
    <div class="settings-actions">
      <el-button @click="resetToDefault" type="info">
        恢复默认设置
      </el-button>
      <el-button @click="exportSettings" type="success">
        导出设置
      </el-button>
      <el-button @click="importSettings" type="warning">
        导入设置
      </el-button>
      <el-button @click="saveSettings" type="primary">
        保存设置
      </el-button>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  Setting, 
  Link, 
  ChatDotRound, 
  Bell, 
  Lock, 
  Tools 
} from '@element-plus/icons-vue'

// Emits
const emit = defineEmits(['save'])

// 响应式数据
const formRef = ref()

const settings = reactive({
  // 基本设置
  theme: 'light',
  language: 'zh-CN',
  autoStart: false,
  minimizeToTray: true,
  
  // 默认代理设置
  defaultProxy: {
    enabled: false,
    type: 'http',
    host: '',
    port: 8080,
    username: '',
    password: ''
  },
  
  // 翻译设置
  translation: {
    service: 'google',
    defaultTargetLang: 'zh',
    apiKey: '',
    autoDetect: true
  },
  
  // 通知设置
  notification: {
    enabled: true,
    sound: true,
    showPreview: true,
    quietHours: []
  },
  
  // 安全设置
  security: {
    appLock: false,
    password: '',
    autoLockTime: 30,
    dataEncryption: false
  },
  
  // 高级设置
  advanced: {
    developerMode: false,
    hardwareAcceleration: true,
    maxContainers: 20,
    logLevel: 'info',
    autoUpdate: true
  }
})

// 默认设置
const defaultSettings = {
  theme: 'light',
  language: 'zh-CN',
  autoStart: false,
  minimizeToTray: true,
  defaultProxy: {
    enabled: false,
    type: 'http',
    host: '',
    port: 8080,
    username: '',
    password: ''
  },
  translation: {
    service: 'google',
    defaultTargetLang: 'zh',
    apiKey: '',
    autoDetect: true
  },
  notification: {
    enabled: true,
    sound: true,
    showPreview: true,
    quietHours: []
  },
  security: {
    appLock: false,
    password: '',
    autoLockTime: 30,
    dataEncryption: false
  },
  advanced: {
    developerMode: false,
    hardwareAcceleration: true,
    maxContainers: 20,
    logLevel: 'info',
    autoUpdate: true
  }
}

// 方法
const saveSettings = () => {
  emit('save', { ...settings })
}

const resetToDefault = async () => {
  try {
    await ElMessageBox.confirm(
      '确定要恢复默认设置吗？当前设置将会丢失。',
      '确认重置',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    Object.assign(settings, defaultSettings)
    ElMessage.success('设置已恢复为默认值')
  } catch {
    // 用户取消了操作
  }
}

const exportSettings = async () => {
  try {
    const data = JSON.stringify(settings, null, 2)
    
    if (window.electronAPI) {
      const result = await window.electronAPI.saveFile(
        data, 
        `settings_${new Date().toISOString().split('T')[0]}.json`
      )
      
      if (result.success) {
        ElMessage.success('设置已导出')
      } else {
        ElMessage.error('导出失败')
      }
    } else {
      // 浏览器环境，使用下载
      const blob = new Blob([data], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `settings_${new Date().toISOString().split('T')[0]}.json`
      a.click()
      URL.revokeObjectURL(url)
      ElMessage.success('设置已导出')
    }
  } catch (error) {
    ElMessage.error('导出失败')
  }
}

const importSettings = async () => {
  try {
    if (window.electronAPI) {
      const result = await window.electronAPI.loadFile()
      
      if (result.success) {
        const importedSettings = JSON.parse(result.data)
        Object.assign(settings, importedSettings)
        ElMessage.success('设置已导入')
      }
    } else {
      // 浏览器环境，使用文件输入
      const input = document.createElement('input')
      input.type = 'file'
      input.accept = '.json'
      input.onchange = (e) => {
        const file = e.target.files[0]
        if (file) {
          const reader = new FileReader()
          reader.onload = (e) => {
            try {
              const importedSettings = JSON.parse(e.target.result)
              Object.assign(settings, importedSettings)
              ElMessage.success('设置已导入')
            } catch (error) {
              ElMessage.error('设置文件格式错误')
            }
          }
          reader.readAsText(file)
        }
      }
      input.click()
    }
  } catch (error) {
    ElMessage.error('导入失败')
  }
}

const clearBrowserData = async () => {
  try {
    await ElMessageBox.confirm(
      '确定要清理所有浏览数据吗？这将清除所有容器的登录状态、Cookie和缓存数据。',
      '确认清理',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    // 这里应该调用清理浏览数据的API
    ElMessage.success('浏览数据已清理')
  } catch {
    // 用户取消了操作
  }
}

// 组件挂载时加载设置
onMounted(() => {
  const savedSettings = localStorage.getItem('globalSettings')
  if (savedSettings) {
    try {
      const parsed = JSON.parse(savedSettings)
      Object.assign(settings, parsed)
    } catch (error) {
      console.error('Failed to load settings:', error)
    }
  }
})
</script>

<style scoped>
.global-settings {
  max-height: 70vh;
  overflow-y: auto;
  padding: 0 10px;
}

.settings-section {
  margin-bottom: 20px;
}

.section-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
}

.form-item-description {
  font-size: 12px;
  color: #666;
  margin-top: 5px;
  line-height: 1.4;
}

.settings-actions {
  padding: 20px 0;
  text-align: right;
  border-top: 1px solid #eee;
  margin-top: 20px;
  position: sticky;
  bottom: 0;
  background: white;
}

.settings-actions .el-button {
  margin-left: 10px;
}

/* 自定义滚动条 */
.global-settings::-webkit-scrollbar {
  width: 6px;
}

.global-settings::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 3px;
}

.global-settings::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 3px;
}

.global-settings::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}
</style>