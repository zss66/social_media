<template>
  <div class="container-view">
    <!-- 容器工具栏 -->
    <div class="container-toolbar">
      <div class="toolbar-left">
        <el-breadcrumb separator="/">
          <el-breadcrumb-item>{{ container.platform.name }}</el-breadcrumb-item>
          <el-breadcrumb-item>{{ container.name }}</el-breadcrumb-item>
        </el-breadcrumb>
        
        <div class="status-indicator" :class="container.status">
          <el-icon><CircleFilled /></el-icon>
          {{ getStatusText(container.status) }}
        </div>
      </div>
      
      <div class="toolbar-right">
        <el-tooltip content="刷新页面">
          <el-button @click="reloadContainer" :icon="Refresh" circle size="small" />
        </el-tooltip>
        
        <el-tooltip content="开发者工具">
          <el-button @click="toggleDevTools" :icon="Monitor" circle size="small" />
        </el-tooltip>
        
        <el-tooltip content="截图">
          <el-button @click="takeScreenshot" :icon="Camera" circle size="small" />
        </el-tooltip>
        
        <el-tooltip content="设置">
          <el-button @click="showSettings = true" :icon="Setting" circle size="small" />
        </el-tooltip>
      </div>
    </div>
    
    <!-- 主要内容区域 -->
    <div class="container-content">
      <!-- 网页容器 -->
      <div class="webview-container" :style="{ display: showWebview ? 'block' : 'none' }">
        <webview 
          ref="webviewRef"
          :src="container.url"
          :useragent="container.config.fingerprint.userAgent"
          :partition="container.id"
          allowpopups
          webSecurity="false"
          @dom-ready="handleWebviewReady"
          @new-window="handleNewWindow"
          @console-message="handleConsoleMessage"
        />
      </div>
      
      <!-- 加载状态 -->
      <div v-if="!showWebview" class="loading-container">
        <el-loading-directive
          text="正在加载容器..."
          spinner="el-icon-loading"
          background="rgba(0, 0, 0, 0.8)"
        />
      </div>
    </div>
    
    <!-- 浮动工具栏 -->
    <div class="floating-toolbar" v-if="showWebview && container.features">
      <!-- 翻译工具 -->
      <div v-if="container.features.translation" class="feature-panel translation-panel">
        <el-tooltip content="选择文本后点击翻译">
          <el-button 
            @click="translateSelectedText"
            :icon="ChatDotRound"
            type="primary"
            circle
            :loading="translating"
          />
        </el-tooltip>
        
        <el-dropdown @command="handleTranslationLanguage" trigger="click">
          <el-button size="small" type="text">
            {{ currentTranslationLang }}
            <el-icon><ArrowDown /></el-icon>
          </el-button>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="en">英语</el-dropdown-item>
              <el-dropdown-item command="zh">中文</el-dropdown-item>
              <el-dropdown-item command="ja">日语</el-dropdown-item>
              <el-dropdown-item command="ko">韩语</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
      
      <!-- 自动回复工具 -->
      <div v-if="container.features.autoReply" class="feature-panel auto-reply-panel">
        <el-tooltip :content="autoReplyEnabled ? '关闭自动回复' : '开启自动回复'">
          <el-button 
            @click="toggleAutoReply"
            :icon="ChatLineRound"
            :type="autoReplyEnabled ? 'success' : 'info'"
            circle
          />
        </el-tooltip>
        
        <el-badge 
          v-if="autoReplyCount > 0" 
          :value="autoReplyCount" 
          class="reply-count-badge"
        />
      </div>
      
      <!-- 快捷消息 -->
      <div class="feature-panel quick-message-panel">
        <el-dropdown @command="sendQuickMessage" trigger="click">
          <el-button :icon="ChatRound" type="warning" circle />
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="hello">👋 你好</el-dropdown-item>
              <el-dropdown-item command="thanks">🙏 谢谢</el-dropdown-item>
              <el-dropdown-item command="ok">👍 好的</el-dropdown-item>
              <el-dropdown-item command="busy">⏰ 我现在有点忙</el-dropdown-item>
              <el-dropdown-item command="later">🕐 稍后联系</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </div>
    </div>
    
    <!-- 翻译结果弹窗 -->
    <el-dialog v-model="showTranslationResult" title="翻译结果" width="500px">
      <div class="translation-result">
        <div class="original-text">
          <h4>原文：</h4>
          <p>{{ selectedText }}</p>
        </div>
        <div class="translated-text">
          <h4>译文：</h4>
          <p>{{ translatedText }}</p>
        </div>
      </div>
      <template #footer>
        <el-button @click="showTranslationResult = false">关闭</el-button>
        <el-button @click="copyTranslation" type="primary">复制译文</el-button>
      </template>
    </el-dialog>
    
    <!-- 容器设置弹窗 -->
    <el-dialog v-model="showSettings" title="容器设置" width="600px">
      <ContainerSettings 
        :container="container"
        @save="handleSaveSettings"
      />
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { 
  CircleFilled, 
  Refresh, 
  Monitor, 
  Camera, 
  Setting,
  ChatDotRound,
  ChatLineRound,
  ChatRound,
  ArrowDown
} from '@element-plus/icons-vue'
import ContainerSettings from './ContainerSettings.vue'

// Props
const props = defineProps({
  container: {
    type: Object,
    required: true
  }
})

// Emits
const emit = defineEmits(['update-container'])

// 响应式数据
const webviewRef = ref()
const showWebview = ref(false)
const showSettings = ref(false)
const showTranslationResult = ref(false)
const translating = ref(false)
const selectedText = ref('')
const translatedText = ref('')
const currentTranslationLang = ref('英语')
const autoReplyEnabled = ref(false)
const autoReplyCount = ref(0)

// 计算属性
const getStatusText = (status) => {
  const statusMap = {
    'created': '已创建',
    'loading': '加载中',
    'ready': '就绪',
    'error': '错误',
    'disconnected': '断开连接'
  }
  return statusMap[status] || '未知'
}

// 方法
const handleWebviewReady = () => {
  console.log('Webview DOM ready')
  showWebview.value = true
  emit('update-container', props.container.id, { status: 'ready' })
  
  // 注入自定义脚本
  injectCustomScripts()
}

const handleNewWindow = (event) => {
  console.log('New window requested:', event.url)
  // 可以选择在新标签页中打开或者在当前webview中加载
}

const handleConsoleMessage = (event) => {
  console.log('Webview console:', event.message)
}

const injectCustomScripts = () => {
  if (!webviewRef.value) return
  
  // 注入翻译功能脚本
  if (props.container.features.translation) {
    const translationScript = `
      (function() {
        // 创建翻译按钮
        function createTranslationButton() {
          const button = document.createElement('div');
          button.id = 'custom-translate-btn';
          button.style.cssText = \`
            position: fixed;
            top: 10px;
            right: 10px;
            width: 40px;
            height: 40px;
            background: #409EFF;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            z-index: 10000;
            box-shadow: 0 2px 12px rgba(0,0,0,0.1);
          \`;
          button.innerHTML = '译';
          button.onclick = function() {
            const selection = window.getSelection().toString();
            if (selection) {
              window.postMessage({ type: 'translate', text: selection }, '*');
            } else {
              alert('请先选择要翻译的文本');
            }
          };
          document.body.appendChild(button);
        }
        
        // 等待页面加载完成
        if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', createTranslationButton);
        } else {
          createTranslationButton();
        }
      })();
    `
    
    webviewRef.value.executeJavaScript(translationScript)
  }
  
  // 注入自动回复功能脚本
  if (props.container.features.autoReply) {
    const autoReplyScript = `
      (function() {
        // 监听新消息
        function monitorNewMessages() {
          const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
              if (mutation.addedNodes.length > 0) {
                // 检测到新消息，触发自动回复
                window.postMessage({ type: 'newMessage' }, '*');
              }
            });
          });
          
          // 开始监听消息容器的变化
          const messageContainer = document.querySelector('[data-testid="conversation-panel-messages"]') || 
                                 document.querySelector('.message-list') ||
                                 document.querySelector('#main');
          
          if (messageContainer) {
            observer.observe(messageContainer, { childList: true, subtree: true });
          }
        }
        
        setTimeout(monitorNewMessages, 3000);
      })();
    `
    
    webviewRef.value.executeJavaScript(autoReplyScript)
  }
}

const reloadContainer = () => {
  if (webviewRef.value) {
    emit('update-container', props.container.id, { status: 'loading' })
    webviewRef.value.reload()
    showWebview.value = false
  }
}

const toggleDevTools = () => {
  if (webviewRef.value) {
    if (webviewRef.value.isDevToolsOpened()) {
      webviewRef.value.closeDevTools()
    } else {
      webviewRef.value.openDevTools()
    }
  }
}

const takeScreenshot = async () => {
  try {
    if (webviewRef.value) {
      const nativeImage = await webviewRef.value.capturePage()
      const dataURL = nativeImage.toDataURL()
      
      // 创建下载链接
      const link = document.createElement('a')
      link.download = `screenshot_${props.container.name}_${Date.now()}.png`
      link.href = dataURL
      link.click()
      
      ElMessage.success('截图已保存')
    }
  } catch (error) {
    ElMessage.error('截图失败')
  }
}

const translateSelectedText = async () => {
  if (!selectedText.value) {
    ElMessage.warning('请先选择要翻译的文本')
    return
  }
  
  translating.value = true
  try {
    // 模拟翻译API调用
    await new Promise(resolve => setTimeout(resolve, 1500))
    translatedText.value = `[模拟翻译] ${selectedText.value}`
    showTranslationResult.value = true
  } catch (error) {
    ElMessage.error('翻译失败')
  } finally {
    translating.value = false
  }
}

const handleTranslationLanguage = (lang) => {
  const langMap = {
    'en': '英语',
    'zh': '中文', 
    'ja': '日语',
    'ko': '韩语'
  }
  currentTranslationLang.value = langMap[lang]
  ElMessage.info(`翻译语言已切换为${langMap[lang]}`)
}

const copyTranslation = () => {
  navigator.clipboard.writeText(translatedText.value)
  ElMessage.success('译文已复制到剪贴板')
}

const toggleAutoReply = () => {
  autoReplyEnabled.value = !autoReplyEnabled.value
  const status = autoReplyEnabled.value ? '开启' : '关闭'
  ElMessage.info(`自动回复已${status}`)
}

const sendQuickMessage = (command) => {
  const messages = {
    'hello': '你好',
    'thanks': '谢谢',
    'ok': '好的',
    'busy': '我现在有点忙，稍后联系',
    'later': '稍后联系'
  }
  
  const message = messages[command]
  if (message && webviewRef.value) {
    // 向webview注入发送消息的脚本
    const sendScript = `
      (function() {
        // 尝试找到输入框并发送消息
        const inputSelectors = [
          '[data-testid="conversation-compose-box-input"]',
          '.input-container textarea',
          '#main footer [contenteditable="true"]',
          '[contenteditable="true"]'
        ];
        
        let input = null;
        for (const selector of inputSelectors) {
          input = document.querySelector(selector);
          if (input) break;
        }
        
        if (input) {
          input.focus();
          input.textContent = '${message}';
          
          // 触发输入事件
          const event = new Event('input', { bubbles: true });
          input.dispatchEvent(event);
          
          // 尝试找到发送按钮并点击
          setTimeout(() => {
            const sendSelectors = [
              '[data-testid="send-button"]',
              '.send-button',
              '[aria-label*="发送"]',
              'button[type="submit"]'
            ];
            
            for (const selector of sendSelectors) {
              const sendBtn = document.querySelector(selector);
              if (sendBtn && !sendBtn.disabled) {
                sendBtn.click();
                break;
              }
            }
          }, 100);
        }
      })();
    `
    
    webviewRef.value.executeJavaScript(sendScript)
    ElMessage.success(`已发送快捷消息: ${message}`)
  }
}

const handleSaveSettings = (settings) => {
  emit('update-container', props.container.id, { config: settings })
  showSettings.value = false
  ElMessage.success('设置已保存')
}

// 监听webview消息
const handleWebviewMessage = (event) => {
  const { data } = event
  
  if (data.type === 'translate') {
    selectedText.value = data.text
    translateSelectedText()
  } else if (data.type === 'newMessage' && autoReplyEnabled.value) {
    // 处理自动回复
    setTimeout(() => {
      if (props.container.config.autoReplyMessage) {
        sendQuickMessage('custom')
        autoReplyCount.value++
      }
    }, (props.container.config.autoReplyDelay || 3) * 1000)
  }
}

// 生命周期
onMounted(() => {
  // 监听来自webview的消息
  window.addEventListener('message', handleWebviewMessage)
  
  // 设置加载状态
  emit('update-container', props.container.id, { status: 'loading' })
  
  // 3秒后如果还没加载完成，显示webview
  setTimeout(() => {
    if (!showWebview.value) {
      showWebview.value = true
      emit('update-container', props.container.id, { status: 'ready' })
    }
  }, 3000)
})

onUnmounted(() => {
  window.removeEventListener('message', handleWebviewMessage)
})
</script>

<style scoped>
.container-view {
  height: 100%;
  display: flex;
  flex-direction: column;
  position: relative;
}

.container-toolbar {
  height: 50px;
  background: #f8f9fa;
  border-bottom: 1px solid #e9ecef;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 15px;
}

.toolbar-left {
  display: flex;
  align-items: center;
  gap: 15px;
}

.status-indicator {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  padding: 4px 8px;
  border-radius: 12px;
  background: #f0f0f0;
}

.status-indicator.ready {
  background: #f0f9e8;
  color: #52c41a;
}

.status-indicator.loading {
  background: #fff7e6;
  color: #fa8c16;
}

.status-indicator.error {
  background: #fff2f0;
  color: #f5222d;
}

.toolbar-right {
  display: flex;
  gap: 8px;
}

.container-content {
  flex: 1;
  position: relative;
  overflow: hidden;
}

.webview-container {
  width: 100%;
  height: 100%;
}

.webview-container webview {
  width: 100%;
  height: 100%;
  border: none;
}

.loading-container {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
}

.floating-toolbar {
  position: absolute;
  top: 20px;
  right: 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  z-index: 1000;
}

.feature-panel {
  background: white;
  border-radius: 8px;
  padding: 8px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
  display: flex;
  align-items: center;
  gap: 8px;
}

.translation-panel,
.auto-reply-panel,
.quick-message-panel {
  min-width: 60px;
}

.reply-count-badge {
  margin-left: -8px;
  margin-top: -8px;
}

.translation-result {
  padding: 20px 0;
}

.translation-result h4 {
  margin: 0 0 10px 0;
  color: #333;
  font-size: 14px;
}

.translation-result p {
  margin: 0 0 20px 0;
  padding: 15px;
  background: #f8f9fa;
  border-radius: 6px;
  line-height: 1.6;
  color: #555;
}

.original-text p {
  border-left: 3px solid #409EFF;
}

.translated-text p {
  border-left: 3px solid #67C23A;
}
</style>